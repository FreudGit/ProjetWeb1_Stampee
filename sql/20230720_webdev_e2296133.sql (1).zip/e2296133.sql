-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : jeu. 20 juil. 2023 à 18:43
-- Version du serveur :  10.3.39-MariaDB-0+deb10u1
-- Version de PHP : 7.3.31-1~deb10u4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `e2296133`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`ID`, `Nom`) VALUES
(1, 'Animaux'),
(2, 'Personnages célèbres'),
(3, 'Nature'),
(4, 'Sports'),
(5, 'Histoire');

-- --------------------------------------------------------

--
-- Structure de la table `enchere`
--

CREATE TABLE `enchere` (
  `ID` int(11) NOT NULL,
  `UtilisateurID` int(11) DEFAULT NULL,
  `DateDebut` date DEFAULT NULL,
  `DateFin` date DEFAULT NULL,
  `PrixPlancher` decimal(10,2) DEFAULT NULL,
  `Visible` tinyint(1) DEFAULT 1,
  `Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `enchere`
--

INSERT INTO `enchere` (`ID`, `UtilisateurID`, `DateDebut`, `DateFin`, `PrixPlancher`, `Visible`, `Status`) VALUES
(1, 1, '2023-07-07', '2023-07-14', '30.00', 1, 'Terminée'),
(3, 3, '2023-07-09', '2023-07-16', '40.00', 1, 'Terminée'),
(4, 4, '2023-07-10', '2023-07-17', '26.00', 1, 'En cours'),
(5, 4, '2023-07-11', '2023-07-18', '35.00', 1, 'Terminée'),
(6, 4, '2023-07-12', '2023-07-19', '15.00', 1, 'En cours'),
(7, 4, '2023-07-13', '2023-07-20', '45.00', 1, 'Terminée'),
(8, 4, '2023-07-14', '2023-07-21', '10.00', 1, 'En cours'),
(9, 4, '2023-07-15', '2023-07-22', '50.00', 1, 'Terminée'),
(10, 4, '2023-07-16', '2023-07-23', '5.00', 1, 'En cours'),
(11, 2, '2023-07-25', '2023-07-26', '56.00', 1, NULL),
(14, 5, '2023-07-20', '2023-07-28', '77.00', 1, NULL),
(15, 5, '2023-07-03', '2023-08-04', '700.00', 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `favoris`
--

CREATE TABLE `favoris` (
  `ID` int(11) NOT NULL,
  `EnchereID` int(11) DEFAULT NULL,
  `UtilisateurID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `favoris`
--

INSERT INTO `favoris` (`ID`, `EnchereID`, `UtilisateurID`) VALUES
(1, 1, 1),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(7, 15, 5),
(8, 11, 2),
(9, 11, 2),
(10, 15, 2),
(11, 15, 2),
(12, 15, 2);

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE `image` (
  `ID` int(11) NOT NULL,
  `TimbreID` int(11) DEFAULT NULL,
  `CheminImage` varchar(255) DEFAULT NULL,
  `Visible` tinyint(1) DEFAULT 1,
  `Description` varchar(255) DEFAULT NULL,
  `Ordre` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `image`
--

INSERT INTO `image` (`ID`, `TimbreID`, `CheminImage`, `Visible`, `Description`, `Ordre`) VALUES
(1, 1, 'medias/stamps/stamp6.webp', 1, 'Image du timbre Animaux 1', 1),
(2, 1, 'medias/stamps/stamp44.webp', 1, 'Image au dos du timbre Animaux 1', 2),
(3, 2, 'medias/stamps/stamp666.webp', 1, 'Image du timbre Animaux 2', 1),
(4, 3, 'medias/stamps/timbre-1.webp', 1, 'Image du timbre Célébrités 1', 1),
(5, 4, 'medias/stamps/timbre-2.webp', 1, 'Image du timbre Célébrités 2', 1),
(6, 7, 'medias/stamps/a-7-1689097357.jpg', 1, NULL, 1),
(7, 8, 'medias/stamps/a-8-1689869682.jpg', 1, NULL, NULL),
(8, 6, 'medias/stamps/a-6-1689878145.jpg', 1, NULL, NULL),
(9, 8, 'medias/stamps/a-8-1689878281.jpg', 1, NULL, NULL),
(10, 8, 'medias/stamps/a-8-1689878303.jpg', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `offre`
--

CREATE TABLE `offre` (
  `ID` int(11) NOT NULL,
  `EnchereID` int(11) DEFAULT NULL,
  `UtilisateurID` int(11) DEFAULT NULL,
  `Prix` decimal(10,2) DEFAULT NULL,
  `Visible` tinyint(1) DEFAULT 1,
  `Note` varchar(255) DEFAULT NULL,
  `OffreDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `offre`
--

INSERT INTO `offre` (`ID`, `EnchereID`, `UtilisateurID`, `Prix`, `Visible`, `Note`, `OffreDate`) VALUES
(11, 3, 5, '23.04', 1, 'Offre pour enchère 3', '2023-07-06 16:52:18'),
(13, 10, 5, '8.70', 1, 'Offre pour enchère 10', '2023-07-06 16:52:18'),
(14, 9, 1, '24.02', 1, 'Offre pour enchère 9', '2023-07-06 16:52:18'),
(15, 1, 1, '27.86', 1, 'Offre pour enchère 1', '2023-07-06 16:52:18'),
(16, 7, 5, '25.10', 1, 'Offre pour enchère 7', '2023-07-06 16:52:18'),
(17, 6, 1, '11.70', 1, 'Offre pour enchère 6', '2023-07-06 16:52:18'),
(18, 8, 1, '10.00', 1, 'Offre pour enchère 8', '2023-07-06 16:52:18'),
(19, 4, 3, '10.39', 1, 'Offre pour enchère 4', '2023-07-06 16:52:18'),
(20, 5, 4, '19.08', 1, 'Offre pour enchère 5', '2023-07-06 16:52:18'),
(42, 5, 4, '30.77', 1, 'Offre pour enchère 5', '2023-07-06 17:04:30'),
(43, 1, 1, '26.70', 1, 'Offre pour enchère 1', '2023-07-06 17:04:30'),
(44, 9, 3, '20.25', 1, 'Offre pour enchère 9', '2023-07-06 17:04:30'),
(45, 4, 2, '12.13', 1, 'Offre pour enchère 4', '2023-07-06 17:04:30'),
(46, 6, 2, '13.15', 1, 'Offre pour enchère 6', '2023-07-06 17:04:30'),
(47, 3, 3, '10.60', 1, 'Offre pour enchère 3', '2023-07-06 17:04:30'),
(48, 8, 3, '10.00', 1, 'Offre pour enchère 8', '2023-07-06 17:04:30'),
(49, 10, 4, '8.98', 1, 'Offre pour enchère 10', '2023-07-06 17:04:30'),
(51, 7, 5, '43.58', 1, 'Offre pour enchère 7', '2023-07-06 17:04:30'),
(61, 4, 4, '4.11', 1, '', '2023-07-06 17:09:12'),
(62, 5, 4, '37.40', 1, '', '2023-07-06 17:09:12'),
(63, 6, 4, '18.43', 1, '', '2023-07-06 17:09:12'),
(64, 10, 4, '7.87', 1, '', '2023-07-06 17:09:12'),
(65, 10, 4, '5.11', 1, '', '2023-07-06 17:09:12'),
(68, 15, 5, '705.00', 1, NULL, '2023-07-20 12:14:57'),
(69, 15, 1, '710.00', 1, NULL, '2023-07-20 15:25:30'),
(70, 11, 1, '61.00', 1, NULL, '2023-07-20 15:26:15');

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`ID`, `Nom`) VALUES
(1, 'administrateur'),
(2, 'editeur'),
(3, 'correcteur'),
(4, 'client'),
(5, 'visiteur');

-- --------------------------------------------------------

--
-- Structure de la table `timbre`
--

CREATE TABLE `timbre` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(255) DEFAULT NULL,
  `DateCreation` date DEFAULT NULL,
  `Couleur` varchar(255) DEFAULT NULL,
  `PaysOrigine` varchar(255) DEFAULT NULL,
  `EtatCondition` varchar(255) DEFAULT NULL,
  `Tirage` int(11) DEFAULT NULL,
  `Longueur` decimal(10,2) DEFAULT NULL,
  `Largeur` decimal(10,2) DEFAULT NULL,
  `Certifie` tinyint(1) DEFAULT NULL,
  `CategorieID` int(11) DEFAULT NULL,
  `utilisateurID` int(11) DEFAULT NULL,
  `EnchereID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `timbre`
--

INSERT INTO `timbre` (`ID`, `Nom`, `DateCreation`, `Couleur`, `PaysOrigine`, `EtatCondition`, `Tirage`, `Longueur`, `Largeur`, `Certifie`, `CategorieID`, `utilisateurID`, `EnchereID`) VALUES
(1, 'Timbre Animaux 1', '2021-01-01', 'Multicolore', 'Canada', 'Neuf sans charnière', 10000, '30.50', '20.50', 1, 5, NULL, 4),
(2, 'Timbre Animaux 2', '2021-02-01', 'Noir et blanc', 'Paysville', 'Oblitéré', 5000, '25.00', '15.00', 0, 1, NULL, 6),
(3, 'Timbre Célébrités 1', '2021-03-01', 'Multicolore', 'Paystimbre', 'Neuf avec charnière', 8000, '35.00', '25.00', 1, 2, NULL, 5),
(4, 'Timbre Célébrités 2', '2021-04-01', 'Noir et blanc', 'Paystimbre', 'Oblitéré', 4000, '30.00', '20.00', 0, 2, NULL, 10),
(5, 'Timbre Nature 1', '2021-05-01', 'Multicolore', 'Paysprincipal', 'Neuf sans charnière', 6000, '40.00', '30.00', 1, 3, NULL, 10),
(6, 'Timbre de fleur', NULL, 'Bleu', 'Canada', 'Usage', 55, '55.00', '55.00', 1, 5, NULL, 11),
(7, 'user5', NULL, 'user5', 'Afghanistan', 'user5', 88, '555.00', '555.00', 1, 5, NULL, 14),
(8, 'Timbre ancier', NULL, 'Rose et blanc', 'Canada', 'Neuf', 500, '67.00', '76.00', 1, 5, NULL, 15);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `utilisateur_id` int(11) NOT NULL,
  `utilisateur_nom` varchar(255) DEFAULT NULL,
  `utilisateur_prenom` varchar(255) DEFAULT NULL,
  `utilisateur_adresse` varchar(255) DEFAULT NULL,
  `utilisateur_courriel` varchar(255) DEFAULT NULL,
  `utilisateur_mdp` varchar(255) DEFAULT NULL,
  `utilisateur_DateInscription` timestamp NOT NULL DEFAULT current_timestamp(),
  `utilisateur_valide` varchar(255) DEFAULT NULL,
  `utilisateur_renouveler_mdp` varchar(255) DEFAULT '0',
  `utilisateur_rating` decimal(2,1) DEFAULT NULL,
  `utilisateur_roleID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`utilisateur_id`, `utilisateur_nom`, `utilisateur_prenom`, `utilisateur_adresse`, `utilisateur_courriel`, `utilisateur_mdp`, `utilisateur_DateInscription`, `utilisateur_valide`, `utilisateur_renouveler_mdp`, `utilisateur_rating`, `utilisateur_roleID`) VALUES
(1, 'administrateur', 'Charles', NULL, 'administrateur@gmail.com', 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff', '2023-07-06 19:58:16', NULL, 'non', NULL, 1),
(2, 'Lord', 'Stampee', 'Chateau Stampee', 'LordStampee@stampee.com', 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff', '2023-07-06 19:58:16', NULL, 'non', NULL, 2),
(3, 'Editeur', 'Charlesse', NULL, 'editeur@gmail.com', 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff', '2023-07-06 19:58:16', NULL, 'non', NULL, 2),
(4, 'correcteur', 'Charles', NULL, 'correcteur@gmail.com', 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff', '2023-07-06 19:58:16', NULL, 'non', NULL, 3),
(5, 'client', 'CharlesClient', NULL, 'client@gmail.com', 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff', '2023-07-06 19:58:16', NULL, 'non', NULL, 4),
(6, 'visiteur', 'Charless', NULL, 'visiteur@gmail.com', 'ee26b0dd4af7e749aa1a8ee3c10ae9923f618980772e473f8819a5d4940e0db27ac185f8a0e1d5f84f88bc887fd67b143732c304cc5fa9ad8e6f57f50028a8ff', '2023-07-06 19:58:16', NULL, 'non', NULL, 4),
(34, 'testfh', 'francoistest', NULL, 'ddd@test.com', '2c0f45554ae065ca5b7bea528924ac16e608ac64528d74e6fe13b6501712f32f100ce020661b16bfcec0f9c2eaf5007b8b2be897e5769ac33a35b4d0e0a1dadb', '2023-07-20 17:12:24', NULL, 'oui', NULL, 4);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `enchere`
--
ALTER TABLE `enchere`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UtilisateurID` (`UtilisateurID`);

--
-- Index pour la table `favoris`
--
ALTER TABLE `favoris`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UtilisateurID` (`UtilisateurID`),
  ADD KEY `favoris_ibfk_1` (`EnchereID`);

--
-- Index pour la table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `TimbreID` (`TimbreID`);

--
-- Index pour la table `offre`
--
ALTER TABLE `offre`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `EnchereID` (`EnchereID`),
  ADD KEY `UtilisateurID` (`UtilisateurID`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `timbre`
--
ALTER TABLE `timbre`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CategorieID` (`CategorieID`),
  ADD KEY `FK_timbre_utilisateur` (`utilisateurID`),
  ADD KEY `FK_timbre_enchere` (`EnchereID`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`utilisateur_id`),
  ADD KEY `utilisateur_ibfk_1` (`utilisateur_roleID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `enchere`
--
ALTER TABLE `enchere`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `favoris`
--
ALTER TABLE `favoris`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `image`
--
ALTER TABLE `image`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `offre`
--
ALTER TABLE `offre`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT pour la table `role`
--
ALTER TABLE `role`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `timbre`
--
ALTER TABLE `timbre`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `utilisateur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `enchere`
--
ALTER TABLE `enchere`
  ADD CONSTRAINT `enchere_ibfk_2` FOREIGN KEY (`UtilisateurID`) REFERENCES `utilisateur` (`utilisateur_id`);

--
-- Contraintes pour la table `favoris`
--
ALTER TABLE `favoris`
  ADD CONSTRAINT `favoris_ibfk_1` FOREIGN KEY (`EnchereID`) REFERENCES `enchere` (`ID`),
  ADD CONSTRAINT `favoris_ibfk_2` FOREIGN KEY (`UtilisateurID`) REFERENCES `utilisateur` (`utilisateur_id`);

--
-- Contraintes pour la table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `image_ibfk_1` FOREIGN KEY (`TimbreID`) REFERENCES `timbre` (`ID`);

--
-- Contraintes pour la table `offre`
--
ALTER TABLE `offre`
  ADD CONSTRAINT `offre_ibfk_1` FOREIGN KEY (`EnchereID`) REFERENCES `enchere` (`ID`),
  ADD CONSTRAINT `offre_ibfk_2` FOREIGN KEY (`UtilisateurID`) REFERENCES `utilisateur` (`utilisateur_id`);

--
-- Contraintes pour la table `timbre`
--
ALTER TABLE `timbre`
  ADD CONSTRAINT `FK_timbre_enchere` FOREIGN KEY (`EnchereID`) REFERENCES `enchere` (`ID`),
  ADD CONSTRAINT `FK_timbre_utilisateur` FOREIGN KEY (`utilisateurID`) REFERENCES `utilisateur` (`utilisateur_id`),
  ADD CONSTRAINT `timbre_ibfk_1` FOREIGN KEY (`CategorieID`) REFERENCES `categorie` (`ID`);

--
-- Contraintes pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`utilisateur_roleID`) REFERENCES `role` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
